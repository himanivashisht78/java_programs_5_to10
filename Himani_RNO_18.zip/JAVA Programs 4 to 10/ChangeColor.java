/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Himani
 */
import java.awt.*;
import java.awt.event.*;

class ChangeColor extends Frame
{
    int X=10,Y=10;
    public ChangeColor()
    {
        Font f=new Font("Georgia",Font.ITALIC,36);
        setFont(f);

        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                System.exit(0);
            }
        });
    }
    public void paint(Graphics g)
    {
        FontMetrics fm=g.getFontMetrics();

        nextLine("HOPE YOU ARE SAFE....FIGHT CORONA......BEST OF LUCK!!!",g);
    }

    void nextLine(String s, Graphics g)
    {
        FontMetrics fm=g.getFontMetrics();
        Y+=fm.getHeight();
        X=20;
        g.drawString(s,X,Y);
        X+=fm.stringWidth(s);
    }

    public static void main(String[] args)
    {
        ChangeColor appwin = new ChangeColor();
        appwin.setSize(new Dimension(300,300));
        appwin.setTitle("Pink Color");
        appwin.setBackground(Color.pink);
        appwin.setVisible(true);
    }
}

class MyWindowAdapter extends WindowAdapter
{
    public void windowClosing(WindowEvent we)
    {
        System.exit(0);
    }
}

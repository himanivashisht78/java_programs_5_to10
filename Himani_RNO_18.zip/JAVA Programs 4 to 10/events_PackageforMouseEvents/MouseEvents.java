/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package events;

/**
 *
 * @author Himani
 */
import java.applet.*;
import java.awt.event.*;
import java.awt.*;
/*
<applet code="MouseEvents_Himani_Vashisht" width=350 height=60>
</applet>
*/

 class Sample_Frame extends Frame implements MouseListener, MouseMotionListener {
    String msg="";
    int x=10,y=40;
    int mx=0,my=0;
    Sample_Frame(String title)
    {
        super(title);
        addMouseListener(this);
        addMouseMotionListener(this);
        My_Window_Adapter adapter= new My_Window_Adapter(this);
        addWindowListener(adapter);
    }
    public void mouseClicked(MouseEvent m)
    {
        x=10;
        y=54;
        msg="Mouse is just clicked inside child";
       repaint();
    }
    public void mouseEntered(MouseEvent ev){
        x=10;
        y=54;
        msg="Mouse just entered the child";
        repaint();
        this.setVisible(true);
        
    }
    public void mouseExited(MouseEvent ev)
    {
        x=10;
        y=54;
        msg="Mouse just left the child but is in the applet";
        repaint();
      
    }
    public void paint(Graphics g)
    {
        g.drawString(msg, x, y);
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }
    
}
class My_Window_Adapter extends WindowAdapter {
 Sample_Frame smpl;
 public My_Window_Adapter(Sample_Frame sample)
 {
     this.smpl=sample;
 }
 public void windowClosing(MouseEventss me)
 {
     smpl.setVisible(false);
 }
}
public class MouseEvents extends Applet implements MouseListener, MouseMotionListener {
    Sample_Frame f;
    String msg="";
    int x=0,y=10;
    int mx=0,my=0;
    public void init(){
        f=new Sample_Frame("Himani_Handle-Mouse-Events");
        f.setSize(300,200);
        addMouseListener(this);
        addMouseMotionListener(this);
    }
    public void mouseClicked(MouseEvent me)
    {
       x=0;
       y=24;
       msg="Mouse is just clicked";
       repaint();
       
    }
   
    public void mouseEntered(MouseEvent m){
        x=0;
        y=24;
        msg="Mouse just Entered applet window";
        repaint();
        f.setVisible(true);
    }
    public void mouseExited(MouseEvent m)
    {
        x=0;
        y=24;
        msg="Mouse just left applet window";
        repaint();
        f.setVisible(false);
    }
    public void paint(Graphics g)
    {
        g.drawString(msg,x,y);
    }
    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }
      
    
}
